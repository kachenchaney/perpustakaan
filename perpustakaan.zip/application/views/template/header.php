<div class="navbar">
	<div class="container">
		<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo site_url('dashboard');?>"><i class="glyphicon glyphicon-hdd"></i> &nbsp;SI Perpus 1.0</a>
		</div>
	</div>
</div>